<?php


namespace CityPay\Paylink\Api\Data;

//extends \Magento\Framework\Api\ExtensibleDataInterface
interface PaylinkPostbackInterface
{

}