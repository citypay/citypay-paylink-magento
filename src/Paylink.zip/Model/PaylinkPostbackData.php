<?php


namespace CityPay\Paylink\Model;


class PaylinkPostbackData implements \CityPay\Paylink\Api\Data\PaylinkPostbackInterface
{

}